package com.ecommerce.ecommerce_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEcommerceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
